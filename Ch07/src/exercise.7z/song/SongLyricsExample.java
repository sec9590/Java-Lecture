package exercise.song;

public class SongLyricsExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SongLyrics songLyrics = new SongLyrics("Love of My Life", "Queen", "A Night at the Opera",
				new String[] { "프레디머큐리" }, 1975, 9,
				"Love of my life, you\'ve hurt me" + "You\'ve broken my heart and now you leave me"
						+ "Love of my life, can\'t you see?" + "Bring it back, bring it back"
						+ "Don\'t take it away from me, because you don\'t know" + "What it means to me");
		
		songLyrics.show();
	}

}
