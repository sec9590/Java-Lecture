package openchallenge.ex01;

public class SongExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Song song = new Song("Love of My Life", "Queen", "A Night at the Opera", new String[] {"프레디머큐리"}, 1975, 9);
		
		song.show();
	}

}
