package openchallenge.ex02;

public class Mul {
	int a;
	int b;
	
	void setValue(int a, int b) {
		this.a = a;
		this.b = b;
	}
	
	int calculate() {
		return a*b;
	}
}
