package exercise.ex14;

public class MemberExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Member user1 = new Member("홍길동", "hong");
		Member user2 = new Member("강자바", "java");

	}

}
