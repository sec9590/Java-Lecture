package exercise.ex16;

public class Printer {

	void println(int x) {
		System.out.println(x);
	}

	void println(boolean x) {
		System.out.println(x);
	}

	void println(double x) {
		System.out.println(x);
	}
	
	void println(String x) {
		System.out.println(x);
	}
}
