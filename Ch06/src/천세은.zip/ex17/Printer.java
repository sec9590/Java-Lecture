package exercise.ex17;

public class Printer {

	static void println(int x) {
		System.out.println(x);
	}

	static void println(boolean x) {
		System.out.println(x);
	}

	static void println(double x) {
		System.out.println(x);
	}
	
	static void println(String x) {
		System.out.println(x);
	}
}
