package exercise.ex13;

public class Member {
	String name = "천세은";
	String id = "chseeun";
	String password = "123454678";
	int age = 24;
}
